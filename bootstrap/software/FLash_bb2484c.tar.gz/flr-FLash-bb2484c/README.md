FLash
=====

The FLash package for fisheries forecasting